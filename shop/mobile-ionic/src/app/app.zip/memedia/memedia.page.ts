import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'e-cu-memedia',
	templateUrl: './memedia.page.html',
	styleUrls: ['./memedia.page.css']
})
export class MemediaPage implements OnInit {
	constructor() {}

	ngOnInit() {}
}
