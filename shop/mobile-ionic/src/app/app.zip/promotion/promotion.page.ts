import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'e-cu-promotion',
	templateUrl: './promotion.page.html',
	styleUrls: ['./promotion.page.css']
})
export class PromotionPage implements OnInit {
	constructor() {}

	ngOnInit() {}
}
