import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'e-cu-bestmenu',
	templateUrl: './bestmenu.page.html',
	styleUrls: ['./bestmenu.page.css']
})
export class BestmenuPage implements OnInit {
	constructor() {}

	ngOnInit() {}
}
