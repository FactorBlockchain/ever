import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'e-cu-painting',
	templateUrl: './painting.page.html',
	styleUrls: ['./painting.page.css']
})
export class PaintingPage implements OnInit {
	constructor() {}

	ngOnInit() {}
}
