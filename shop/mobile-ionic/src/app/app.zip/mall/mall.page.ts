import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'e-cu-mall',
	templateUrl: './mall.page.html',
	styleUrls: ['./mall.page.css']
})
export class MallPage implements OnInit {
	constructor() {}

	ngOnInit() {}
}
